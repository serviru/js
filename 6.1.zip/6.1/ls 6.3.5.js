'use strict';
let inputs = document.querySelectorAll('input');
inputs.forEach(function(input) {
    input.style.marginBottom = '10px';
});

