'use strict';
setTimeout(function() {
    alert('message');
}, 3000 ;


