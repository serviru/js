'use strict';
let img = document.querySelector('img');
img.setAttribute('src', 'images/2 .jpg');
