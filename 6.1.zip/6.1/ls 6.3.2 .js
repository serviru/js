'use strict';
let divs = document.getElementsByTagName('div');
for (let i = 0; i < divs.length; i++) {
    divs[i].style.padding = '10px';
}

